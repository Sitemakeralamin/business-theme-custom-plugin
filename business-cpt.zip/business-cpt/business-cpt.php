<?php
/**
 * @package business
 */
/*
Plugin Name: Business Custom Post
Plugin URI: https://akismet.com/
Description: Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.
Version: 4.1.9
Author: md alamin
Author URI: https://alamin.com/wordpress-plugins/
Text Domain: alamin
*/

// 
// Custom Post Register Testomonial
//

function custom_post(){
register_post_type('testomonial',array(

	'labels' => array(
	
		'name'=>__('testomonials','alamin'),
		'singular_name'=>__('testomonial','alamin'),
		'add_new'=>__('add testomonial','alamin'),
		'add_new_item'=>__('add new testomonial','alamin'),
		'edit_item'=>__('edit testomonial','alamin'),
		 'view_item'=>__('view testomonial','alamin'),
		 'search_items'=>__('search testomonial','alamin'),
	
	),
	
	'public'=> true,
	



));
	
	
// 
// Custom Post Register Our Team
//	

	register_post_type('team',array(

	'labels' => array(
	
		'name'=>__('Our Team','alamin'),
		'singular_name'=>__('Ourtems','alamin'),
		'add_new'=>__('add Team members','alamin'),
		'add_new_item'=>__('add new Member','alamin'),
		'edit_item'=>__('edit Team member','alamin'),
		 'view_item'=>__('view Team','alamin'),
		 'search_items'=>__('search Team','alamin'),
	
	),
	
	'public'=> true,
	 'supports' => array( 'title', 'editor', 'thumbnail','page-attributes' ),
		



));
	
	
}
add_action('init','custom_post');

